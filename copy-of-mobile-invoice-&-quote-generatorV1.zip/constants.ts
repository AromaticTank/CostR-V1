import { AppSettings, CompanyInfo, DocumentType, PDFTemplate, UserSlot } from './types';

export const APP_NAME = "Business Hub"; // Updated App Name

export const DEFAULT_CURRENCY = "ZAR"; // Changed to ZAR
export const DEFAULT_TAX_RATE = 15; // Standard SA VAT rate, can be adjusted in settings
export const MAX_USER_SLOTS = 5;

export const EMPTY_COMPANY_INFO: CompanyInfo = {
  name: '',
  address: '',
  email: '',
  phone: '',
  logoUrl: '',
  bankDetails: '',
  taxId: '',
};

export const DEFAULT_ADMIN_USER_SLOT: UserSlot = {
  id: crypto.randomUUID(), // Initial admin user
  name: 'Admin User',
  role: 'Administrator',
  isActive: true,
  isPrimaryAdmin: true,
};

export const DEFAULT_SETTINGS: AppSettings = {
  company: EMPTY_COMPANY_INFO,
  defaultCurrency: DEFAULT_CURRENCY,
  defaultTaxRate: DEFAULT_TAX_RATE,
  secondaryTaxRate: undefined, // Or 0 if it should always be a number
  selectedPdfTemplate: PDFTemplate.Template1,
  isSetupComplete: false,
  primaryColor: '#3B82F6', // Default Blue
  secondaryColor: '#10B981', // Default Emerald
  userSlots: [DEFAULT_ADMIN_USER_SLOT],
  maxUserSlots: MAX_USER_SLOTS,
};

export const DOCUMENT_TYPES_OPTIONS = [
  { label: 'Invoice', value: DocumentType.Invoice },
  { label: 'Quotation', value: DocumentType.Quotation },
];

export const CURRENCIES = ['ZAR', 'USD', 'EUR', 'GBP', 'JPY', 'CAD', 'AUD']; // Added ZAR

export const PDF_TEMPLATE_OPTIONS = [
  { label: 'Standard Template', value: PDFTemplate.Template1 },
  { label: 'Modern Template', value: PDFTemplate.Template2 },
];