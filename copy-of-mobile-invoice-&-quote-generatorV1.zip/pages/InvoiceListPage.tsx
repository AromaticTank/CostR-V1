
import React from 'react';
import { Link } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
import DocumentCard from '../components/DocumentCard';
import FloatingActionButton from '../components/FloatingActionButton';
// Fix: Import InvoicesIcon instead of Receipt
import { InvoicesIcon } from '../components/icons';


const InvoiceListPage: React.FC = () => {
  const { documents } = useDocuments();
  const invoices = documents.filter(doc => doc.docType === 'Invoice')
                            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <div className="animate-fadeIn">
      <h1 className="text-3xl font-bold text-onSurface mb-8">Invoices</h1>
      {invoices.length === 0 ? (
        <div className="text-center py-10 bg-surface shadow-lg rounded-xl p-8">
           {/* Fix: Use InvoicesIcon */}
           <InvoicesIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-xl text-gray-600">No invoices yet.</p>
          <p className="text-gray-500">Create your first invoice to see it here.</p>
           <Link 
            to="/new-invoice" 
            className="mt-6 inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-onPrimary bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light"
          >
            Create Invoice
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {invoices.map(doc => (
            <DocumentCard key={doc.id} doc={doc} />
          ))}
        </div>
      )}
      {/* <FloatingActionButton to="/new-invoice" title="Create New Invoice" /> */}
    </div>
  );
};

export default InvoiceListPage;
