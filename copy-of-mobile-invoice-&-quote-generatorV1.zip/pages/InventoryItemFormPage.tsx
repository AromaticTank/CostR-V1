
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
import { InventoryItem } from '../types';
import { ArrowLeftIcon, InventoryIcon } from '../components/icons';

const InventoryItemFormPage: React.FC = () => {
  const { addInventoryItem, updateInventoryItem, getInventoryItemById, settings } = useDocuments();
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditing = Boolean(id);

  const [item, setItem] = useState<Omit<InventoryItem, 'id' | 'createdAt' | 'updatedAt'>>({
    name: '',
    sku: '',
    description: '',
    quantityOnHand: 0,
    unitPrice: 0,
    costPrice: undefined,
    supplier: '',
    lastReorderDate: undefined,
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const currencyFormat = new Intl.NumberFormat(undefined, { style: 'currency', currency: settings.defaultCurrency, minimumFractionDigits: 2 });


  useEffect(() => {
    if (isEditing && id) {
      const existingItem = getInventoryItemById(id);
      if (existingItem) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { id: itemId, createdAt, updatedAt, ...formData } = existingItem;
        setItem(formData);
      } else {
        navigate('/inventory'); // Item not found
      }
    } else {
      setItem({ name: '', sku: '', description: '', quantityOnHand: 0, unitPrice: 0, costPrice: undefined, supplier: '', lastReorderDate: undefined});
    }
  }, [id, isEditing, getInventoryItemById, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setItem(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!item.name.trim()) errors.name = "Item name is required.";
    if (item.quantityOnHand < 0) errors.quantityOnHand = "Quantity on hand cannot be negative.";
    if (item.unitPrice < 0) errors.unitPrice = "Unit price cannot be negative.";
    if (item.costPrice && item.costPrice < 0) errors.costPrice = "Cost price cannot be negative.";
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const now = new Date().toISOString();
    const inventoryItemData: InventoryItem = {
      ...item,
      unitPrice: Number(item.unitPrice) || 0, // Ensure numbers
      quantityOnHand: Number(item.quantityOnHand) || 0,
      costPrice: item.costPrice ? Number(item.costPrice) : undefined,
      id: isEditing && id ? id : crypto.randomUUID(),
      createdAt: isEditing ? (getInventoryItemById(id!)?.createdAt || now) : now,
      updatedAt: now,
    };

    if (isEditing) {
      updateInventoryItem(inventoryItemData);
    } else {
      addInventoryItem(inventoryItemData);
    }
    navigate('/inventory');
  };

  return (
    <div className="max-w-2xl mx-auto bg-surface p-6 sm:p-8 rounded-xl shadow-xl">
      <button onClick={() => navigate('/inventory')} className="flex items-center text-primary hover:text-primary-dark mb-6 group">
        <ArrowLeftIcon className="w-5 h-5 mr-2 transition-transform group-hover:-translate-x-1" />
        Back to Inventory
      </button>
      <div className="flex items-center mb-8">
        <InventoryIcon className="w-8 h-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold text-onSurface">{isEditing ? 'Edit Item' : 'Add New Item'}</h1>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">Item Name *</label>
          <input type="text" id="name" name="name" value={item.name} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
          {formErrors.name && <p className="text-danger text-xs mt-1">{formErrors.name}</p>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="sku" className="block text-sm font-medium text-gray-700">SKU (Stock Keeping Unit)</label>
                <input type="text" id="sku" name="sku" value={item.sku || ''} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
            </div>
            <div>
                <label htmlFor="quantityOnHand" className="block text-sm font-medium text-gray-700">Quantity on Hand *</label>
                <input type="number" id="quantityOnHand" name="quantityOnHand" value={item.quantityOnHand} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
                {formErrors.quantityOnHand && <p className="text-danger text-xs mt-1">{formErrors.quantityOnHand}</p>}
            </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="unitPrice" className="block text-sm font-medium text-gray-700">Unit Price ({settings.defaultCurrency}) *</label>
                <input type="number" step="0.01" id="unitPrice" name="unitPrice" value={item.unitPrice} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
                {formErrors.unitPrice && <p className="text-danger text-xs mt-1">{formErrors.unitPrice}</p>}
            </div>
             <div>
                <label htmlFor="costPrice" className="block text-sm font-medium text-gray-700">Cost Price ({settings.defaultCurrency}) (Optional)</label>
                <input type="number" step="0.01" id="costPrice" name="costPrice" value={item.costPrice === undefined ? '' : item.costPrice} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" placeholder="e.g., 10.50"/>
                {formErrors.costPrice && <p className="text-danger text-xs mt-1">{formErrors.costPrice}</p>}
            </div>
        </div>
        
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description (Optional)</label>
          <textarea id="description" name="description" value={item.description || ''} onChange={handleInputChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
        </div>
        
        <div>
          <label htmlFor="supplier" className="block text-sm font-medium text-gray-700">Supplier (Optional)</label>
          <input type="text" id="supplier" name="supplier" value={item.supplier || ''} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
        </div>

        <div>
          <label htmlFor="lastReorderDate" className="block text-sm font-medium text-gray-700">Last Reorder Date (Optional)</label>
          <input type="date" id="lastReorderDate" name="lastReorderDate" value={item.lastReorderDate || ''} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
        </div>

        {Object.keys(formErrors).length > 0 && (
            <div className="my-4 p-3 bg-red-100 text-danger rounded-md text-sm">
                Please correct the errors above before saving.
            </div>
        )}

        <div className="flex justify-end space-x-4 pt-4">
          <button type="button" onClick={() => navigate('/inventory')} className="px-6 py-2.5 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-100 transition-colors">
            Cancel
          </button>
          <button type="submit" className="px-6 py-2.5 bg-primary hover:bg-primary-dark text-sm text-onPrimary rounded-lg shadow-md hover:shadow-lg transition-all">
            {isEditing ? 'Save Changes' : 'Add Item'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default InventoryItemFormPage;
