
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
import { CURRENCIES, DEFAULT_CURRENCY, APP_NAME } from '../constants';
import { ArrowLeftIcon, Palette } from 'lucide-react'; // Using lucide directly

const SetupPage: React.FC = () => {
  const { completeSetup, settings } = useDocuments();
  const navigate = useNavigate();

  const [companyName, setCompanyName] = useState(settings.company.name || '');
  const [companyEmail, setCompanyEmail] = useState(settings.company.email || '');
  const [currency, setCurrency] = useState(settings.defaultCurrency || DEFAULT_CURRENCY);
  const [primaryColor, setPrimaryColor] = useState(settings.primaryColor || '#3B82F6'); // Default Blue
  const [secondaryColor, setSecondaryColor] = useState(settings.secondaryColor || '#10B981'); // Default Emerald
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!companyName.trim()) newErrors.companyName = "Company name is required.";
    if (!companyEmail.trim()) newErrors.companyEmail = "Company email is required.";
    else if (!/\S+@\S+\.\S+/.test(companyEmail)) newErrors.companyEmail = "Invalid email format.";
    if (!primaryColor.match(/^#[0-9a-fA-F]{6}$/)) newErrors.primaryColor = "Primary color must be a valid hex code (e.g., #RRGGBB).";
    if (!secondaryColor.match(/^#[0-9a-fA-F]{6}$/)) newErrors.secondaryColor = "Secondary color must be a valid hex code (e.g., #RRGGBB).";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    completeSetup(companyName, companyEmail, currency, primaryColor, secondaryColor);
    navigate('/dashboard', { replace: true });
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
      <div className="w-full max-w-md bg-surface shadow-xl rounded-xl p-6 sm:p-8">
        <div className="text-center mb-8">
            <Palette className="w-16 h-16 text-primary mx-auto mb-3" />
          <h1 className="text-3xl font-bold text-onSurface">Welcome to {APP_NAME}!</h1>
          <p className="text-gray-600 mt-2">Let's set up your business profile.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="companyName" className="block text-sm font-medium text-gray-700">Company Name</label>
            <input
              type="text"
              id="companyName"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3"
              placeholder="Your Awesome Company"
            />
            {errors.companyName && <p className="text-danger text-xs mt-1">{errors.companyName}</p>}
          </div>

          <div>
            <label htmlFor="companyEmail" className="block text-sm font-medium text-gray-700">Company Email</label>
            <input
              type="email"
              id="companyEmail"
              value={companyEmail}
              onChange={(e) => setCompanyEmail(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3"
              placeholder="you@example.com"
            />
            {errors.companyEmail && <p className="text-danger text-xs mt-1">{errors.companyEmail}</p>}
          </div>

          <div>
            <label htmlFor="currency" className="block text-sm font-medium text-gray-700">Default Currency</label>
            <select
              id="currency"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3 bg-white"
            >
              {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
                <label htmlFor="primaryColor" className="block text-sm font-medium text-gray-700">Primary Color</label>
                <div className="mt-1 flex rounded-md shadow-sm">
                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                        <div style={{ backgroundColor: primaryColor }} className="w-5 h-5 rounded-sm border border-gray-400"></div>
                    </span>
                    <input
                        type="text"
                        id="primaryColor"
                        value={primaryColor}
                        onChange={(e) => setPrimaryColor(e.target.value)}
                        className="block w-full rounded-none rounded-r-md border-gray-300 focus:border-primary focus:ring-primary sm:text-sm p-3"
                        placeholder="#3B82F6"
                    />
                </div>
                {errors.primaryColor && <p className="text-danger text-xs mt-1">{errors.primaryColor}</p>}
            </div>
             <div>
                <label htmlFor="secondaryColor" className="block text-sm font-medium text-gray-700">Secondary Color</label>
                 <div className="mt-1 flex rounded-md shadow-sm">
                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                         <div style={{ backgroundColor: secondaryColor }} className="w-5 h-5 rounded-sm border border-gray-400"></div>
                    </span>
                    <input
                        type="text"
                        id="secondaryColor"
                        value={secondaryColor}
                        onChange={(e) => setSecondaryColor(e.target.value)}
                        className="block w-full rounded-none rounded-r-md border-gray-300 focus:border-primary focus:ring-primary sm:text-sm p-3"
                        placeholder="#10B981"
                    />
                </div>
                {errors.secondaryColor && <p className="text-danger text-xs mt-1">{errors.secondaryColor}</p>}
            </div>
          </div>


          <button
            type="submit"
            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-onPrimary bg-primary hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-light transition-colors"
          >
            Complete Setup
          </button>
        </form>
      </div>
       <p className="mt-8 text-center text-sm text-gray-500">
        Already set up? This page should only appear on first launch.
      </p>
    </div>
  );
};

export default SetupPage;
