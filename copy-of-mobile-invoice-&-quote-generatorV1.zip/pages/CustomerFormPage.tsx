
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
import { Customer } from '../types';
import { ArrowLeftIcon, CustomersIcon } from '../components/icons';

const CustomerFormPage: React.FC = () => {
  const { addCustomer, updateCustomer, getCustomerById } = useDocuments();
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditing = Boolean(id);

  const [customer, setCustomer] = useState<Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>>({
    name: '',
    email: '',
    phone: '',
    address: '',
    notes: '',
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isEditing && id) {
      const existingCustomer = getCustomerById(id);
      if (existingCustomer) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { id: custId, createdAt, updatedAt, ...formData } = existingCustomer;
        setCustomer(formData);
      } else {
        navigate('/customers'); // Customer not found
      }
    } else {
      setCustomer({ name: '', email: '', phone: '', address: '', notes: '' }); // Reset for new form
    }
  }, [id, isEditing, getCustomerById, navigate]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCustomer(prev => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!customer.name.trim()) errors.name = "Customer name is required.";
    if (!customer.email.trim()) errors.email = "Email is required.";
    else if (!/\S+@\S+\.\S+/.test(customer.email)) errors.email = "Email is invalid.";
    // Add other validations as needed (e.g., phone format)
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const now = new Date().toISOString();
    const customerData: Customer = {
      ...customer,
      id: isEditing && id ? id : crypto.randomUUID(),
      createdAt: isEditing ? (getCustomerById(id!)?.createdAt || now) : now,
      updatedAt: now,
    };

    if (isEditing) {
      updateCustomer(customerData);
    } else {
      addCustomer(customerData);
    }
    navigate('/customers');
  };

  return (
    <div className="max-w-2xl mx-auto bg-surface p-6 sm:p-8 rounded-xl shadow-xl">
      <button onClick={() => navigate('/customers')} className="flex items-center text-primary hover:text-primary-dark mb-6 group">
        <ArrowLeftIcon className="w-5 h-5 mr-2 transition-transform group-hover:-translate-x-1" />
        Back to Customers
      </button>
      <div className="flex items-center mb-8">
        <CustomersIcon className="w-8 h-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold text-onSurface">{isEditing ? 'Edit Customer' : 'Add New Customer'}</h1>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700">Full Name *</label>
          <input type="text" id="name" name="name" value={customer.name} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
          {formErrors.name && <p className="text-danger text-xs mt-1">{formErrors.name}</p>}
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address *</label>
          <input type="email" id="email" name="email" value={customer.email} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
          {formErrors.email && <p className="text-danger text-xs mt-1">{formErrors.email}</p>}
        </div>
        <div>
          <label htmlFor="phone" className="block text-sm font-medium text-gray-700">Phone Number (Optional)</label>
          <input type="tel" id="phone" name="phone" value={customer.phone || ''} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
        </div>
        <div>
          <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address (Optional)</label>
          <textarea id="address" name="address" value={customer.address || ''} onChange={handleInputChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
        </div>
        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700">Notes (Optional)</label>
          <textarea id="notes" name="notes" value={customer.notes || ''} onChange={handleInputChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
        </div>
        
        {Object.keys(formErrors).length > 0 && (
            <div className="my-4 p-3 bg-red-100 text-danger rounded-md text-sm">
                Please correct the errors above before saving.
            </div>
        )}

        <div className="flex justify-end space-x-4 pt-4">
          <button type="button" onClick={() => navigate('/customers')} className="px-6 py-2.5 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-100 transition-colors">
            Cancel
          </button>
          <button type="submit" className="px-6 py-2.5 bg-primary hover:bg-primary-dark text-sm text-onPrimary rounded-lg shadow-md hover:shadow-lg transition-all">
            {isEditing ? 'Save Changes' : 'Add Customer'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CustomerFormPage;
