
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
import { PaymentTransaction, PaymentDirection } from '../types';
import { ArrowLeftIcon, PaymentsInIcon, PaymentsOutIcon } from '../components/icons';
import { CURRENCIES } from '../constants';

interface PaymentFormPageProps {
  direction?: 'In' | 'Out'; // Passed via route for new payments
}

const PaymentFormPage: React.FC<PaymentFormPageProps> = ({ direction: routeDirection }) => {
  const { addPaymentTransaction, updatePaymentTransaction, getPaymentTransactionById, settings, documents } = useDocuments();
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>(); // For editing existing payment
  const isEditing = Boolean(id);

  const [transaction, setTransaction] = useState<Omit<PaymentTransaction, 'id' | 'createdAt' | 'updatedAt'>>({
    direction: routeDirection ? PaymentDirection[routeDirection] : PaymentDirection.In,
    date: new Date().toISOString().split('T')[0],
    amount: 0,
    currency: settings.defaultCurrency,
    description: '',
    category: '',
    relatedDocumentId: '',
    paymentMethod: '',
    notes: '',
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isEditing && id) {
      const existingTransaction = getPaymentTransactionById(id);
      if (existingTransaction) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { id: transId, createdAt, updatedAt, ...formData } = existingTransaction;
        setTransaction(formData);
      } else {
        // Fix: Use transaction.direction as formData is out of scope here.
        // This handles the case where an ID is provided for editing, but the transaction isn't found.
        navigate(transaction.direction === PaymentDirection.In ? '/payments-in' : '/payments-out'); // Transaction not found
      }
    } else if (routeDirection) {
      // For new transactions, set direction from route and defaults
      setTransaction({
        direction: PaymentDirection[routeDirection],
        date: new Date().toISOString().split('T')[0],
        amount: 0,
        currency: settings.defaultCurrency,
        description: '',
        category: '',
        relatedDocumentId: '',
        paymentMethod: '',
        notes: '',
      });
    }
  }, [id, isEditing, getPaymentTransactionById, navigate, routeDirection, settings.defaultCurrency, transaction.direction]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    setTransaction(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : (name === 'direction' ? value as PaymentDirection : value),
    }));
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (transaction.amount <= 0) errors.amount = "Amount must be greater than zero.";
    if (!transaction.description.trim()) errors.description = "Description is required.";
    if (!transaction.date) errors.date = "Date is required.";
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const now = new Date().toISOString();
    const paymentData: PaymentTransaction = {
      ...transaction,
      amount: Number(transaction.amount) || 0,
      id: isEditing && id ? id : crypto.randomUUID(),
      createdAt: isEditing ? (getPaymentTransactionById(id!)?.createdAt || now) : now,
      updatedAt: now,
    };

    if (isEditing) {
      updatePaymentTransaction(paymentData);
    } else {
      addPaymentTransaction(paymentData);
    }
    navigate(paymentData.direction === PaymentDirection.In ? '/payments-in' : '/payments-out');
  };

  const pageTitle = isEditing 
    ? `Edit ${transaction.direction === PaymentDirection.In ? 'Incoming Payment' : 'Expense'}`
    : `Log New ${transaction.direction === PaymentDirection.In ? 'Incoming Payment' : 'Expense'}`;

  const PageIcon = transaction.direction === PaymentDirection.In ? PaymentsInIcon : PaymentsOutIcon;

  const availableInvoices = documents.filter(doc => doc.docType === "Invoice").map(doc => ({ value: doc.id, label: `${doc.docNumber} - ${doc.client.name}` }));


  return (
    <div className="max-w-2xl mx-auto bg-surface p-6 sm:p-8 rounded-xl shadow-xl">
      <button onClick={() => navigate(transaction.direction === PaymentDirection.In ? '/payments-in' : '/payments-out')} className="flex items-center text-primary hover:text-primary-dark mb-6 group">
        <ArrowLeftIcon className="w-5 h-5 mr-2 transition-transform group-hover:-translate-x-1" />
        Back to Payments
      </button>
      <div className="flex items-center mb-8">
        <PageIcon className={`w-8 h-8 mr-3 ${transaction.direction === PaymentDirection.In ? 'text-green-500' : 'text-danger'}`} />
        <h1 className="text-3xl font-bold text-onSurface">{pageTitle}</h1>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        {!isEditing && ( // Allow changing direction only for new transactions if needed, or lock it based on entry point.
             <div>
                <label htmlFor="direction" className="block text-sm font-medium text-gray-700">Type *</label>
                <select id="direction" name="direction" value={transaction.direction} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3 bg-white">
                    <option value={PaymentDirection.In}>Incoming Payment</option>
                    <option value={PaymentDirection.Out}>Expense / Outgoing Payment</option>
                </select>
            </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="date" className="block text-sm font-medium text-gray-700">Date *</label>
                <input type="date" id="date" name="date" value={transaction.date} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
                {formErrors.date && <p className="text-danger text-xs mt-1">{formErrors.date}</p>}
            </div>
            <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700">Amount ({transaction.currency}) *</label>
                <input type="number" step="0.01" id="amount" name="amount" value={transaction.amount} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
                {formErrors.amount && <p className="text-danger text-xs mt-1">{formErrors.amount}</p>}
            </div>
        </div>
        
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-700">Description *</label>
          <input type="text" id="description" name="description" value={transaction.description} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" placeholder={transaction.direction === PaymentDirection.In ? "e.g., Payment for INV-0001" : "e.g., Office Supplies"}/>
          {formErrors.description && <p className="text-danger text-xs mt-1">{formErrors.description}</p>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label htmlFor="currency" className="block text-sm font-medium text-gray-700">Currency</label>
                <select id="currency" name="currency" value={transaction.currency} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3 bg-white">
                    {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700">Category (Optional)</label>
                <input type="text" id="category" name="category" value={transaction.category || ''} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" placeholder={transaction.direction === PaymentDirection.In ? "e.g., Sales, Service Fee" : "e.g., Software, Marketing, Rent"}/>
            </div>
        </div>

        {transaction.direction === PaymentDirection.In && (
            <div>
                <label htmlFor="relatedDocumentId" className="block text-sm font-medium text-gray-700">Related Invoice (Optional)</label>
                <select id="relatedDocumentId" name="relatedDocumentId" value={transaction.relatedDocumentId || ''} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3 bg-white">
                    <option value="">None</option>
                    {availableInvoices.map(inv => <option key={inv.value} value={inv.value}>{inv.label}</option>)}
                </select>
            </div>
        )}
        
        <div>
            <label htmlFor="paymentMethod" className="block text-sm font-medium text-gray-700">Payment Method (Optional)</label>
            <input type="text" id="paymentMethod" name="paymentMethod" value={transaction.paymentMethod || ''} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" placeholder="e.g., Bank Transfer, Credit Card, Cash"/>
        </div>

        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700">Notes (Optional)</label>
          <textarea id="notes" name="notes" value={transaction.notes || ''} onChange={handleInputChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-3" />
        </div>
        
        {Object.keys(formErrors).length > 0 && (
            <div className="my-4 p-3 bg-red-100 text-danger rounded-md text-sm">
                Please correct the errors above before saving.
            </div>
        )}

        <div className="flex justify-end space-x-4 pt-4">
          <button type="button" onClick={() => navigate(transaction.direction === PaymentDirection.In ? '/payments-in' : '/payments-out')} className="px-6 py-2.5 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-100 transition-colors">
            Cancel
          </button>
          <button type="submit" className="px-6 py-2.5 bg-primary hover:bg-primary-dark text-sm text-onPrimary rounded-lg shadow-md hover:shadow-lg transition-all">
            {isEditing ? 'Save Changes' : 'Log Payment'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PaymentFormPage;