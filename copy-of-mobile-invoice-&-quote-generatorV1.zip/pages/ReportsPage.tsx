
import React from 'react';
import { ReportsIcon } from '../components/icons'; // Placeholder icon

const ReportsPage: React.FC = () => {
  return (
    <div className="animate-fadeIn">
      <h1 className="text-3xl font-bold text-onSurface mb-8">Reports</h1>
      <div className="text-center py-10 bg-surface shadow-lg rounded-xl p-8">
        <ReportsIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-xl text-gray-600">Financial Reports</p>
        <p className="text-gray-500">Generate reports for tax submissions (e.g., SARS) and business insights.</p>
        <p className="text-sm text-orange-500 mt-4">(Feature coming soon)</p>
      </div>
    </div>
  );
};

export default ReportsPage;
