
import React from 'react';
import { Link } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
// Fix: Update icon imports to use correctly exported names
import { PlusIcon, QuotesIcon, InvoicesIcon, CustomersIcon, ReportsIcon } from '../components/icons'; 


// Example data - replace with actual data from context or API
const quickStatsData = [
  // Fix: Use QuotesIcon if this data were to be used
  { title: 'Active Quotes', value: 5, color: 'bg-blue-500', icon: <QuotesIcon className="w-8 h-8 text-blue-100" /> },
  // Fix: Use InvoicesIcon if this data were to be used
  { title: 'Unpaid Invoices', value: 3, color: 'bg-red-500', icon: <InvoicesIcon className="w-8 h-8 text-red-100" /> },
  // Fix: Use CustomersIcon if this data were to be used
  { title: 'Total Customers', value: 12, color: 'bg-green-500', icon: <CustomersIcon className="w-8 h-8 text-green-100" /> },
  // Fix: Use InventoryIcon if this data were to be used (InventoryIcon would need to be imported)
  // { title: 'Inventory Items', value: 45, color: 'bg-yellow-500', icon: <Archive className="w-8 h-8 text-yellow-100" /> }, 
];

const DashboardPage: React.FC = () => {
  const { settings, documents }
 = useDocuments(); // Get documents to calculate some stats

  const activeQuotes = documents.filter(doc => doc.docType === 'Quotation').length; // Example stat
  const unpaidInvoices = documents.filter(doc => doc.docType === 'Invoice').length; // Example stat, needs payment status in future

  const stats = [
    // Fix: Use QuotesIcon
    { title: 'Active Quotes', value: activeQuotes, color: 'bg-primary', icon: <QuotesIcon className="w-8 h-8 text-onPrimary" />, link: '/quotes' },
    // Fix: Use InvoicesIcon
    { title: 'Total Invoices', value: unpaidInvoices, color: 'bg-secondary', icon: <InvoicesIcon className="w-8 h-8 text-onPrimary" />, link: '/invoices' },
    // Fix: Use CustomersIcon
    { title: 'Customers', value: settings.company?.name ? 1 : 0, /* TODO: Replace with actual customer count */ icon: <CustomersIcon className="w-8 h-8 text-onPrimary" />, color: 'bg-emerald-500', link: '/customers'},
    // Fix: Use ReportsIcon
    { title: 'Reports', value: 'View', icon: <ReportsIcon className="w-8 h-8 text-onPrimary" />, color: 'bg-purple-500', link: '/reports' },
  ];


  return (
    <div className="animate-fadeIn space-y-8">
      <section className="bg-surface p-6 rounded-xl shadow-lg">
        <h1 className="text-3xl font-bold text-onSurface mb-2">
          Welcome back, {settings.company.name || 'User'}!
        </h1>
        <p className="text-gray-600">Here's a quick overview of your business.</p>
      </section>

      {/* Quick Stats Section */}
      <section>
        <h2 className="text-2xl font-semibold text-onSurface mb-4">Quick Stats</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map(stat => (
            <Link to={stat.link} key={stat.title} className={`p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow flex items-start space-x-4 ${stat.color}`}>
              <div className={`p-3 rounded-full bg-white/20`}>
                {stat.icon}
              </div>
              <div>
                <p className="text-3xl font-bold text-onPrimary">{stat.value}</p>
                <p className="text-sm text-onPrimary/90">{stat.title}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Quick Actions Section */}
      <section>
        <h2 className="text-2xl font-semibold text-onSurface mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link to="/new-quotation" className="bg-surface p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow flex flex-col items-center justify-center text-center hover:border-primary border-2 border-transparent">
            <PlusIcon className="w-10 h-10 text-primary mb-2" />
            <p className="font-semibold text-onSurface">Create New Quotation</p>
            <p className="text-sm text-gray-500">Draft a new quote for a client.</p>
          </Link>
          <Link to="/new-invoice" className="bg-surface p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow flex flex-col items-center justify-center text-center hover:border-primary border-2 border-transparent">
            <PlusIcon className="w-10 h-10 text-primary mb-2" />
            <p className="font-semibold text-onSurface">Create New Invoice</p>
            <p className="text-sm text-gray-500">Generate an invoice for payment.</p>
          </Link>
          <Link to="/customers" className="bg-surface p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow flex flex-col items-center justify-center text-center hover:border-primary border-2 border-transparent">
            {/* Fix: Use CustomersIcon */}
            <CustomersIcon className="w-10 h-10 text-primary mb-2" />
            <p className="font-semibold text-onSurface">Manage Customers</p>
            <p className="text-sm text-gray-500">View and edit customer details.</p>
          </Link>
        </div>
      </section>
      
      {/* Placeholder for recent activity or other dashboard widgets */}
      <section className="bg-surface p-6 rounded-xl shadow-lg mt-8">
        <h2 className="text-2xl font-semibold text-onSurface mb-4">Recent Activity</h2>
        {documents.length > 0 ? (
          <ul className="space-y-3">
            {documents.slice(0, 5).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(doc => (
              <li key={doc.id} className="p-3 bg-gray-50 rounded-md hover:bg-gray-100 transition-colors">
                <Link to={`/view/${doc.id}`} className="flex justify-between items-center">
                  <div>
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full mr-2 ${doc.docType === 'Invoice' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}`}>{doc.docType}</span>
                    <span className="font-medium text-onSurface">{doc.docNumber}</span>
                    <span className="text-sm text-gray-500 ml-2">- {doc.client.name}</span>
                  </div>
                  <span className="text-sm text-gray-500">{new Date(doc.createdAt).toLocaleDateString()}</span>
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500">No recent activity to display. Create a document to get started!</p>
        )}
      </section>

    </div>
  );
};

export default DashboardPage;

// Basic fade-in animation (can be moved to a global CSS if used often)
const style = document.createElement('style');
style.innerHTML = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fadeIn { animation: fadeIn 0.5s ease-out forwards; }
`;
document.head.appendChild(style);