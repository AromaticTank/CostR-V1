
import React from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
import PrintView from '../components/PrintView';
import { PencilIcon, PrinterIcon, ArrowLeftIcon } from '../components/icons';

const DocumentViewPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getDocumentById } = useDocuments();
  const navigate = useNavigate();
  const doc = id ? getDocumentById(id) : undefined;

  if (!doc) {
    return (
      <div className="text-center py-10">
        <h1 className="text-2xl font-bold text-danger mb-4">Document Not Found</h1>
        <p className="text-gray-600 mb-6">The document you are looking for does not exist or has been deleted.</p>
        <button
          onClick={() => navigate('/')}
          className="px-6 py-3 bg-primary hover:bg-primary-dark text-onPrimary rounded-lg shadow-md hover:shadow-lg transition-all flex items-center mx-auto"
        >
          <ArrowLeftIcon className="w-5 h-5 mr-2"/>
          Back to List
        </button>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6 flex flex-wrap justify-between items-center gap-4 print-hide">
        <button onClick={() => navigate('/')} className="flex items-center text-primary hover:text-primary-dark group">
          <ArrowLeftIcon className="w-5 h-5 mr-2 transition-transform group-hover:-translate-x-1" />
          Back to List
        </button>
        <div className="flex space-x-3">
          <Link
            to={`/edit/${doc.id}`}
            className="flex items-center px-4 py-2 bg-secondary hover:bg-green-600 text-onSecondary rounded-lg shadow hover:shadow-md transition-all"
          >
            <PencilIcon className="w-5 h-5 mr-2" /> Edit
          </Link>
          <button
            onClick={handlePrint}
            className="flex items-center px-4 py-2 bg-primary hover:bg-primary-dark text-onPrimary rounded-lg shadow hover:shadow-md transition-all"
          >
            <PrinterIcon className="w-5 h-5 mr-2" /> Print / Save PDF
          </button>
        </div>
      </div>
      <PrintView doc={doc} />
    </div>
  );
};

export default DocumentViewPage;
