
import React from 'react';
import { Link } from 'react-router-dom';
import { PaymentsOutIcon, PlusIcon, PencilIcon, TrashIcon } from '../components/icons';
import { useDocuments } from '../contexts/DocumentContext';
import { PaymentTransaction, PaymentDirection } from '../types';

const PaymentsOutPage: React.FC = () => {
  const { paymentTransactions, deletePaymentTransaction, settings } = useDocuments();
  const outgoingPayments = paymentTransactions
    .filter(p => p.direction === PaymentDirection.Out)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const currencyFormat = (amount: number, currency: string) => 
    new Intl.NumberFormat(undefined, { style: 'currency', currency: currency || settings.defaultCurrency }).format(amount);

  const handleDelete = (id: string, description: string) => {
    if (window.confirm(`Are you sure you want to delete expense "${description}"?`)) {
      deletePaymentTransaction(id);
    }
  };

  return (
    <div className="animate-fadeIn">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-onSurface">Expenses / Payments Out</h1>
        <Link
          to="/payments/new/out"
          className="bg-primary hover:bg-primary-dark text-onPrimary font-medium py-2.5 px-5 rounded-lg shadow hover:shadow-md transition-all flex items-center text-sm"
        >
          <PlusIcon className="w-5 h-5 mr-2" /> Log Expense
        </Link>
      </div>

      {outgoingPayments.length === 0 ? (
        <div className="text-center py-12 bg-surface shadow-lg rounded-xl p-8">
          <PaymentsOutIcon className="w-20 h-20 text-gray-400 mx-auto mb-6" />
          <p className="text-xl text-gray-600 mb-2">No expenses logged.</p>
          <p className="text-gray-500 mb-6">Keep track of your business spending by logging expenses here.</p>
          <Link
            to="/payments/new/out"
            className="bg-primary hover:bg-primary-dark text-onPrimary font-medium py-3 px-6 rounded-lg shadow hover:shadow-md transition-all flex items-center mx-auto w-fit"
            >
             <PlusIcon className="w-5 h-5 mr-2" /> Log First Expense
            </Link>
        </div>
      ) : (
        <div className="bg-surface shadow-xl rounded-xl overflow-hidden">
          <ul className="divide-y divide-gray-200">
            {outgoingPayments.map(payment => (
              <li key={payment.id} className="p-4 sm:p-6 hover:bg-gray-50 transition-colors">
                 <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex-grow">
                    <p className="text-lg font-semibold text-danger">{currencyFormat(payment.amount, payment.currency)}</p>
                    <p className="text-sm text-gray-700">{payment.description}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      Date: {new Date(payment.date).toLocaleDateString()}
                      {payment.category && ` | Category: ${payment.category}`}
                      {payment.paymentMethod && ` | Method: ${payment.paymentMethod}`}
                    </p>
                    {payment.relatedDocumentId && <p className="text-xs text-gray-500 mt-1">Related Doc: {payment.relatedDocumentId}</p>}
                  </div>
                   <div className="flex space-x-2 flex-shrink-0 mt-2 sm:mt-0">
                    <Link 
                      to={`/payments/edit/${payment.id}`} // Make sure PaymentFormPage handles loading existing payment by ID
                      className="p-2 text-gray-500 hover:text-secondary transition-colors rounded-full hover:bg-secondary/10"
                      title="Edit Expense"
                    >
                      <PencilIcon className="w-5 h-5" />
                    </Link>
                    <button
                      onClick={() => handleDelete(payment.id, payment.description)}
                      className="p-2 text-gray-500 hover:text-danger transition-colors rounded-full hover:bg-danger/10"
                      title="Delete Expense"
                    >
                      <TrashIcon className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default PaymentsOutPage;
