
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
import { Document, DocumentType, LineItem, ClientInfo, CompanyInfo, Customer } from '../types';
import LineItemRow from '../components/LineItemRow';
import { PlusIcon, ArrowLeftIcon } from '../components/icons';
import { CURRENCIES, DOCUMENT_TYPES_OPTIONS, EMPTY_COMPANY_INFO } from '../constants';

interface DocumentFormPageProps {
  initialDocumentType?: 'Invoice' | 'Quotation';
}

const DocumentFormPage: React.FC<DocumentFormPageProps> = ({ initialDocumentType }) => {
  const { 
    addDocument, updateDocument, getDocumentById, settings, generateDocumentNumber,
    customers, getCustomerById // For customer selection
  } = useDocuments();
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditing = Boolean(id);

  const [doc, setDoc] = useState<Omit<Document, 'id' | 'createdAt' | 'updatedAt' | 'subtotal' | 'taxAmount' | 'total'>>({
    docType: initialDocumentType ? DocumentType[initialDocumentType] : DocumentType.Invoice,
    docNumber: '',
    client: { name: '', email: '', address: '', phone: '' },
    customerId: undefined,
    company: settings.company || EMPTY_COMPANY_INFO,
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: '',
    items: [{ id: crypto.randomUUID(), description: '', quantity: 1, unitPrice: 0 }],
    notes: '',
    currency: settings.defaultCurrency,
    taxRate: settings.defaultTaxRate,
    // secondaryTaxAmount: undefined,
    status: 'Draft',
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');


  const calculateTotals = useCallback((items: LineItem[], taxRate: number, secondaryTaxRate?: number) => {
    const subtotal = items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
    const taxAmount = subtotal * (taxRate / 100);
    // let currentTotal = subtotal + taxAmount;
    // let secTaxAmount;
    // if (secondaryTaxRate && secondaryTaxRate > 0) {
    //     secTaxAmount = subtotal * (secondaryTaxRate / 100);
    //     currentTotal += secTaxAmount;
    // }
    const total = subtotal + taxAmount;
    return { subtotal, taxAmount, total /*, secondaryTaxAmount: secTaxAmount*/ };
  }, []);

  useEffect(() => {
    if (isEditing && id) {
      const existingDoc = getDocumentById(id);
      if (existingDoc) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const { subtotal, taxAmount, total, createdAt, updatedAt, ...formData } = existingDoc;
        setDoc(formData);
        setSelectedCustomerId(formData.customerId || '');
      } else {
        navigate('/dashboard'); 
      }
    } else {
      const defaultType = initialDocumentType ? DocumentType[initialDocumentType] : doc.docType;
      setDoc(prev => ({
        ...prev,
        docType: defaultType,
        docNumber: generateDocumentNumber(defaultType),
        company: settings.company || EMPTY_COMPANY_INFO,
        currency: settings.defaultCurrency,
        taxRate: settings.defaultTaxRate,
        client: { name: '', email: '', address: '', phone: '' }, 
        customerId: undefined,
        items: [{ id: crypto.randomUUID(), description: '', quantity: 1, unitPrice: 0 }], 
        notes: '',
        issueDate: new Date().toISOString().split('T')[0],
        dueDate: '',
        status: 'Draft',
      }));
      setSelectedCustomerId('');
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isEditing, getDocumentById, navigate, settings.company, settings.defaultCurrency, settings.defaultTaxRate, initialDocumentType]);

  useEffect(() => {
    if (!isEditing) {
        setDoc(prev => ({ ...prev, docNumber: generateDocumentNumber(prev.docType) }));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [doc.docType, isEditing]); 

  // Populate client info when a customer is selected
   useEffect(() => {
    if (selectedCustomerId) {
      const customer = getCustomerById(selectedCustomerId);
      if (customer) {
        setDoc(prev => ({
          ...prev,
          client: {
            name: customer.name,
            email: customer.email,
            address: customer.address || '',
            phone: customer.phone || '',
          },
          customerId: customer.id,
        }));
         setFormErrors(prev => ({...prev, 'client.name': '', 'client.email': ''})); // Clear errors
      }
    } else if (!isEditing) { // If deselected or new form, clear client if not editing
        setDoc(prev => ({
            ...prev,
            client: { name: '', email: '', address: '', phone: '' },
            customerId: undefined,
        }));
    }
  }, [selectedCustomerId, getCustomerById, isEditing]);


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setDoc(prev => ({ ...prev, [name]: value }));
    if (formErrors[name]) setFormErrors(prev => ({...prev, [name]: ''}));
  };

  const handleClientChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    // If manually changing client details, deselect customerId
    setSelectedCustomerId(''); 
    setDoc(prev => ({ ...prev, client: { ...prev.client, [name]: value } as ClientInfo, customerId: undefined }));
     if (formErrors[`client.${name}`]) setFormErrors(prev => ({...prev, [`client.${name}`]: ''}));
  };
  
  const handleCompanyChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setDoc(prev => ({ ...prev, company: { ...prev.company, [name]: value } as CompanyInfo }));
  };

  const handleItemChange = (index: number, field: keyof LineItem, value: string | number) => {
    const newItems = [...doc.items];
    newItems[index] = { ...newItems[index], [field]: value };
    setDoc(prev => ({ ...prev, items: newItems }));
  };

  const addItem = () => {
    setDoc(prev => ({
      ...prev,
      items: [...prev.items, { id: crypto.randomUUID(), description: '', quantity: 1, unitPrice: 0 }]
    }));
  };

  const removeItem = (index: number) => {
    if (doc.items.length <= 1) return; 
    const newItems = doc.items.filter((_, i) => i !== index);
    setDoc(prev => ({ ...prev, items: newItems }));
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};
    if (!doc.docNumber.trim()) errors.docNumber = "Document number is required.";
    if (!doc.client.name.trim()) errors['client.name'] = "Client name is required.";
    if (!doc.client.email.trim()) errors['client.email'] = "Client email is required.";
    else if (!/\S+@\S+\.\S+/.test(doc.client.email)) errors['client.email'] = "Client email is invalid.";
    if (!doc.issueDate) errors.issueDate = "Issue date is required.";
    if (doc.docType === DocumentType.Invoice && !doc.dueDate) errors.dueDate = "Due date is required for invoices.";
    
    doc.items.forEach((item, index) => {
        if(!item.description.trim()) errors[`item_desc_${index}`] = `Item ${index + 1} description is required.`;
        if(item.quantity <= 0) errors[`item_qty_${index}`] = `Item ${index + 1} quantity must be positive.`;
        if(item.unitPrice < 0) errors[`item_price_${index}`] = `Item ${index + 1} price cannot be negative.`;
    });

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    const { subtotal, taxAmount, total /*, secondaryTaxAmount*/ } = calculateTotals(doc.items, doc.taxRate, settings.secondaryTaxRate);
    const fullDoc: Document = {
      ...doc,
      id: isEditing && id ? id : crypto.randomUUID(),
      customerId: selectedCustomerId || undefined,
      subtotal,
      taxAmount,
      total,
      // secondaryTaxAmount,
      createdAt: isEditing ? (getDocumentById(id!)?.createdAt || new Date().toISOString()) : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (isEditing) {
      updateDocument(fullDoc);
    } else {
      addDocument(fullDoc);
    }
    navigate(`/view/${fullDoc.id}`);
  };
  
  const { subtotal, taxAmount, total } = calculateTotals(doc.items, doc.taxRate, settings.secondaryTaxRate);
  const currencyFormat = new Intl.NumberFormat(undefined, { style: 'currency', currency: doc.currency });


  return (
    <div className="max-w-4xl mx-auto bg-surface p-4 sm:p-6 md:p-8 rounded-xl shadow-xl">
      <button onClick={() => navigate(-1)} className="flex items-center text-primary hover:text-primary-dark mb-6 group">
        <ArrowLeftIcon className="w-5 h-5 mr-2 transition-transform group-hover:-translate-x-1" />
        Back
      </button>
      <h1 className="text-3xl font-bold text-onSurface mb-8">{isEditing ? 'Edit' : 'Create'} {doc.docType}</h1>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        <section className="p-4 md:p-6 bg-gray-50 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Document Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="docType" className="block text-sm font-medium text-gray-700">Type</label>
              <select id="docType" name="docType" value={doc.docType} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2 bg-white">
                {DOCUMENT_TYPES_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="docNumber" className="block text-sm font-medium text-gray-700">Number</label>
              <input type="text" id="docNumber" name="docNumber" value={doc.docNumber} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
              {formErrors.docNumber && <p className="text-danger text-xs mt-1">{formErrors.docNumber}</p>}
            </div>
            <div>
              <label htmlFor="issueDate" className="block text-sm font-medium text-gray-700">Issue Date</label>
              <input type="date" id="issueDate" name="issueDate" value={doc.issueDate} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
              {formErrors.issueDate && <p className="text-danger text-xs mt-1">{formErrors.issueDate}</p>}
            </div>
            {doc.docType === DocumentType.Invoice && (
              <div>
                <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700">Due Date</label>
                <input type="date" id="dueDate" name="dueDate" value={doc.dueDate || ''} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                {formErrors.dueDate && <p className="text-danger text-xs mt-1">{formErrors.dueDate}</p>}
              </div>
            )}
             <div>
                <label htmlFor="status" className="block text-sm font-medium text-gray-700">Status</label>
                <select id="status" name="status" value={doc.status} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2 bg-white">
                    <option value="Draft">Draft</option>
                    <option value="Sent">Sent</option>
                    {doc.docType === DocumentType.Invoice && <option value="Paid">Paid</option>}
                    {doc.docType === DocumentType.Invoice && <option value="Overdue">Overdue</option>}
                    <option value="Void">Void</option>
                </select>
            </div>
          </div>
        </section>

        <section className="p-4 md:p-6 bg-gray-50 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Your Company</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="companyName" className="block text-sm font-medium text-gray-700">Company Name</label>
              <input type="text" id="companyName" name="name" value={doc.company.name} onChange={handleCompanyChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
            </div>
             <div>
              <label htmlFor="companyEmail" className="block text-sm font-medium text-gray-700">Company Email</label>
              <input type="email" id="companyEmail" name="email" value={doc.company.email || ''} onChange={handleCompanyChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
            </div>
            <div className="md:col-span-2">
              <label htmlFor="companyAddress" className="block text-sm font-medium text-gray-700">Company Address</label>
              <textarea id="companyAddress" name="address" value={doc.company.address} onChange={handleCompanyChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
            </div>
          </div>
        </section>

        <section className="p-4 md:p-6 bg-gray-50 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Client Information</h2>
             {customers.length > 0 && (
                <div className="mb-4">
                    <label htmlFor="selectCustomer" className="block text-sm font-medium text-gray-700">Select Existing Customer (Optional)</label>
                    <select 
                        id="selectCustomer" 
                        value={selectedCustomerId} 
                        onChange={(e) => setSelectedCustomerId(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2 bg-white"
                    >
                        <option value="">-- Enter Manually or Select --</option>
                        {customers.map(cust => (
                            <option key={cust.id} value={cust.id}>{cust.name} ({cust.email})</option>
                        ))}
                    </select>
                    <p className="text-xs text-gray-500 mt-1">Selecting a customer will auto-fill their details below. Manual edits will detach from the saved customer for this document.</p>
                </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label htmlFor="clientName" className="block text-sm font-medium text-gray-700">Client Name *</label>
                    <input type="text" id="clientName" name="name" value={doc.client.name} onChange={handleClientChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                    {formErrors['client.name'] && <p className="text-danger text-xs mt-1">{formErrors['client.name']}</p>}
                </div>
                <div>
                    <label htmlFor="clientEmail" className="block text-sm font-medium text-gray-700">Client Email *</label>
                    <input type="email" id="clientEmail" name="email" value={doc.client.email} onChange={handleClientChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                    {formErrors['client.email'] && <p className="text-danger text-xs mt-1">{formErrors['client.email']}</p>}
                </div>
                <div className="md:col-span-2">
                    <label htmlFor="clientAddress" className="block text-sm font-medium text-gray-700">Client Address</label>
                    <textarea id="clientAddress" name="address" value={doc.client.address} onChange={handleClientChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                </div>
                 <div>
                    <label htmlFor="clientPhone" className="block text-sm font-medium text-gray-700">Client Phone (Optional)</label>
                    <input type="tel" id="clientPhone" name="phone" value={doc.client.phone || ''} onChange={handleClientChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                </div>
            </div>
        </section>

        <section>
          <h2 className="text-xl font-semibold text-gray-700 mb-4">Items</h2>
          {/* TODO: Future - Add button to select items from Inventory */}
          <div className="space-y-1">
            {doc.items.map((item, index) => (
              <div key={item.id}>
                <LineItemRow item={item} index={index} onChange={handleItemChange} onRemove={removeItem} currency={doc.currency} />
                {formErrors[`item_desc_${index}`] && <p className="text-danger text-xs mt-1">{formErrors[`item_desc_${index}`]}</p>}
                {formErrors[`item_qty_${index}`] && <p className="text-danger text-xs mt-1">{formErrors[`item_qty_${index}`]}</p>}
                {formErrors[`item_price_${index}`] && <p className="text-danger text-xs mt-1">{formErrors[`item_price_${index}`]}</p>}
              </div>
            ))}
          </div>
          <button type="button" onClick={addItem} className="mt-4 flex items-center text-sm text-primary hover:text-primary-dark font-medium py-2 px-4 rounded-lg border border-primary hover:bg-primary-light/10 transition-colors">
            <PlusIcon className="w-4 h-4 mr-2" /> Add Item Manually
          </button>
        </section>

        <section className="p-4 md:p-6 bg-gray-50 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Notes & Financials</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                    <label htmlFor="notes" className="block text-sm font-medium text-gray-700">Notes (Optional)</label>
                    <textarea id="notes" name="notes" value={doc.notes || ''} onChange={handleInputChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                </div>
                <div>
                    <label htmlFor="currency" className="block text-sm font-medium text-gray-700">Currency</label>
                    <select id="currency" name="currency" value={doc.currency} onChange={handleInputChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2 bg-white">
                        {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                </div>
                <div>
                    <label htmlFor="taxRate" className="block text-sm font-medium text-gray-700">Tax Rate (%)</label>
                    <input type="number" id="taxRate" name="taxRate" value={doc.taxRate} onChange={(e) => setDoc(prev => ({...prev, taxRate: parseFloat(e.target.value) || 0}))} step="0.01" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                </div>
                 {/* Optional: Secondary Tax Rate Field, if enabled in settings */}
                 {/* {settings.secondaryTaxRate !== undefined && settings.secondaryTaxRate > 0 && (
                    <div>
                        <label htmlFor="applySecondaryTax" className="block text-sm font-medium text-gray-700">Apply Secondary Tax ({settings.secondaryTaxRate}%)</label>
                        <input type="checkbox" id="applySecondaryTax" name="applySecondaryTax" ... />
                    </div>
                 )} */}
            </div>
        </section>

        <div className="mt-8 p-4 md:p-6 bg-gray-100 rounded-lg">
            <div className="flex justify-between items-center text-gray-700 mb-2">
                <span>Subtotal:</span>
                <span className="font-medium">{currencyFormat.format(subtotal)}</span>
            </div>
            <div className="flex justify-between items-center text-gray-700 mb-2">
                <span>Tax ({doc.taxRate}%):</span>
                <span className="font-medium">{currencyFormat.format(taxAmount)}</span>
            </div>
            {/* {settings.secondaryTaxRate && settings.secondaryTaxRate > 0 && calculateTotals(doc.items, doc.taxRate, settings.secondaryTaxRate).secondaryTaxAmount && (
                 <div className="flex justify-between items-center text-gray-700 mb-2">
                    <span>Secondary Tax ({settings.secondaryTaxRate}%):</span>
                    <span className="font-medium">{currencyFormat.format(calculateTotals(doc.items, doc.taxRate, settings.secondaryTaxRate).secondaryTaxAmount!)}</span>
                </div>
            )} */}
            <hr className="my-2 border-gray-300"/>
            <div className="flex justify-between items-center text-xl font-bold text-onSurface">
                <span>Total:</span>
                <span>{currencyFormat.format(total)}</span>
            </div>
        </div>
        
        {Object.keys(formErrors).length > 0 && (
            <div className="my-4 p-3 bg-red-100 text-danger rounded-md text-sm">
                Please correct the errors above before saving.
            </div>
        )}

        <div className="flex justify-end space-x-4 pt-6">
            <button type="button" onClick={() => navigate(-1)} className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors">
                Cancel
            </button>
            <button type="submit" className="px-6 py-3 bg-primary hover:bg-primary-dark text-onPrimary rounded-lg shadow-md hover:shadow-lg transition-all">
                {isEditing ? 'Save Changes' : 'Create Document'}
            </button>
        </div>
      </form>
    </div>
  );
};

export default DocumentFormPage;
