
import React from 'react';
import { Link } from 'react-router-dom';
import { PlusIcon, CustomersIcon, PencilIcon, TrashIcon } from '../components/icons'; 
import { useDocuments } from '../contexts/DocumentContext';

const CustomerListPage: React.FC = () => {
  const { customers, deleteCustomer } = useDocuments();

  const sortedCustomers = [...customers].sort((a, b) => a.name.localeCompare(b.name));

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete customer "${name}"? This action cannot be undone.`)) {
      deleteCustomer(id);
    }
  };

  return (
    <div className="animate-fadeIn">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-onSurface">Customers</h1>
        <Link
          to="/customers/new"
          className="bg-primary hover:bg-primary-dark text-onPrimary font-medium py-2.5 px-5 rounded-lg shadow hover:shadow-md transition-all flex items-center text-sm"
        >
          <PlusIcon className="w-5 h-5 mr-2" /> Add Customer
        </Link>
      </div>

      {sortedCustomers.length === 0 ? (
        <div className="text-center py-12 bg-surface shadow-lg rounded-xl p-8">
          <CustomersIcon className="w-20 h-20 text-gray-400 mx-auto mb-6" />
          <p className="text-xl text-gray-600 mb-2">No customers yet.</p>
          <p className="text-gray-500 mb-6">Click "Add Customer" to get started and manage your client list.</p>
           <Link
            to="/customers/new"
            className="bg-primary hover:bg-primary-dark text-onPrimary font-medium py-3 px-6 rounded-lg shadow hover:shadow-md transition-all flex items-center mx-auto w-fit"
            >
            <PlusIcon className="w-5 h-5 mr-2" /> Add First Customer
            </Link>
        </div>
      ) : (
        <div className="bg-surface shadow-xl rounded-xl overflow-hidden">
          <ul className="divide-y divide-gray-200">
            {sortedCustomers.map(customer => (
              <li key={customer.id} className="p-4 sm:p-6 hover:bg-gray-50 transition-colors">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex-grow">
                    <p className="text-lg font-semibold text-primary-dark">{customer.name}</p>
                    <p className="text-sm text-gray-600">{customer.email}</p>
                    {customer.phone && <p className="text-xs text-gray-500 mt-1">Phone: {customer.phone}</p>}
                    {customer.address && <p className="text-xs text-gray-500 mt-1">Address: {customer.address}</p>}
                  </div>
                  <div className="flex space-x-2 flex-shrink-0 mt-2 sm:mt-0">
                    <Link 
                      to={`/customers/edit/${customer.id}`}
                      className="p-2 text-gray-500 hover:text-secondary transition-colors rounded-full hover:bg-secondary/10"
                      title="Edit Customer"
                    >
                      <PencilIcon className="w-5 h-5" />
                    </Link>
                    <button
                      onClick={() => handleDelete(customer.id, customer.name)}
                      className="p-2 text-gray-500 hover:text-danger transition-colors rounded-full hover:bg-danger/10"
                      title="Delete Customer"
                    >
                      <TrashIcon className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default CustomerListPage;
