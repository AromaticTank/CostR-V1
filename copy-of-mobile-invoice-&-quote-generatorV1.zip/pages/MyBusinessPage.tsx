
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MyBusinessIcon } from '../components/icons'; // Placeholder icon
import { useDocuments } from '../contexts/DocumentContext';

const MyBusinessPage: React.FC = () => {
  const navigate = useNavigate();
  const { settings } = useDocuments();

  // Consider redirecting to the specific section in Settings if My Business is fully merged.
  // useEffect(() => {
  //   navigate('/settings#myBusiness', { replace: true });
  // }, [navigate]);

  return (
    <div className="animate-fadeIn">
      <h1 className="text-3xl font-bold text-onSurface mb-8">My Business Profile</h1>
      <div className="bg-surface shadow-xl rounded-xl p-8">
        <div className="flex flex-col items-center text-center">
            {settings.company.logoUrl ? (
                <img src={settings.company.logoUrl} alt={`${settings.company.name} logo`} className="w-24 h-24 rounded-full object-cover mb-4 border-2 border-primary p-1" />
            ) : (
                <MyBusinessIcon className="w-24 h-24 text-gray-400 mb-4" />
            )}
          <h2 className="text-2xl font-semibold text-primary-dark">{settings.company.name || "Your Company Name"}</h2>
          <p className="text-gray-600 mt-1">{settings.company.email || "your@companyemail.com"}</p>
          <p className="text-gray-500 text-sm mt-1">{settings.company.address || "Your company address"}</p>
        </div>

        <div className="mt-8 border-t pt-6">
            <h3 className="text-lg font-semibold text-onSurface mb-3">Details:</h3>
            <ul className="space-y-2 text-sm text-gray-700">
                <li><strong>Phone:</strong> {settings.company.phone || "N/A"}</li>
                <li><strong>Tax ID:</strong> {settings.company.taxId || "N/A"}</li>
                <li><strong>Bank Details:</strong> {settings.company.bankDetails || "N/A"}</li>
                <li><strong>Default Currency:</strong> {settings.defaultCurrency}</li>
                <li><strong>Default Tax Rate:</strong> {settings.defaultTaxRate}%</li>
            </ul>
        </div>

        <div className="mt-8 text-center">
            <button
                onClick={() => navigate('/settings')}
                className="px-6 py-3 bg-primary hover:bg-primary-dark text-onPrimary rounded-lg shadow-md hover:shadow-lg transition-all text-sm font-medium"
            >
                Edit Business Profile & Settings
            </button>
        </div>
         <p className="text-xs text-gray-400 mt-6 text-center">
            All business details, theme colors, and document defaults can be managed in the Settings section.
        </p>
      </div>
    </div>
  );
};

export default MyBusinessPage;
