
import React from 'react';
import { Link } from 'react-router-dom';
import { PlusIcon, InventoryIcon, PencilIcon, TrashIcon } from '../components/icons'; 
import { useDocuments } from '../contexts/DocumentContext';
import { InventoryItem } from '../types';

const InventoryListPage: React.FC = () => {
  const { inventoryItems, deleteInventoryItem, settings } = useDocuments();

  const sortedInventory = [...inventoryItems].sort((a,b) => a.name.localeCompare(b.name));
  const currencyFormat = new Intl.NumberFormat(undefined, { style: 'currency', currency: settings.defaultCurrency });

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to delete inventory item "${name}"? This action cannot be undone.`)) {
      deleteInventoryItem(id);
    }
  };


  return (
    <div className="animate-fadeIn">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-onSurface">Inventory</h1>
        <Link
          to="/inventory/new"
          className="bg-primary hover:bg-primary-dark text-onPrimary font-medium py-2.5 px-5 rounded-lg shadow hover:shadow-md transition-all flex items-center text-sm"
        >
          <PlusIcon className="w-5 h-5 mr-2" /> Add Item
        </Link>
      </div>

      {sortedInventory.length === 0 ? (
        <div className="text-center py-12 bg-surface shadow-lg rounded-xl p-8">
          <InventoryIcon className="w-20 h-20 text-gray-400 mx-auto mb-6" />
          <p className="text-xl text-gray-600 mb-2">Your inventory is empty.</p>
          <p className="text-gray-500 mb-6">Click "Add Item" to populate your inventory with products or services.</p>
           <Link
            to="/inventory/new"
            className="bg-primary hover:bg-primary-dark text-onPrimary font-medium py-3 px-6 rounded-lg shadow hover:shadow-md transition-all flex items-center mx-auto w-fit"
            >
            <PlusIcon className="w-5 h-5 mr-2" /> Add First Item
            </Link>
        </div>
      ) : (
        <div className="bg-surface shadow-xl rounded-xl overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKU</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Stock</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Unit Price</th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedInventory.map(item => (
                <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{item.name}</div>
                    {item.description && <div className="text-xs text-gray-500 truncate max-w-xs">{item.description}</div>}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.sku || 'N/A'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">{item.quantityOnHand}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 text-right">{currencyFormat.format(item.unitPrice)}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-center">
                    <Link 
                        to={`/inventory/edit/${item.id}`} 
                        className="text-secondary hover:text-green-700 mr-3 p-1 rounded-full hover:bg-secondary/10"
                        title="Edit Item"
                    >
                        <PencilIcon className="w-4 h-4"/>
                    </Link>
                    <button
                        onClick={() => handleDelete(item.id, item.name)}
                        className="text-danger hover:text-red-700 p-1 rounded-full hover:bg-danger/10"
                        title="Delete Item"
                    >
                        {/* Fix: Changed BUTTON to button */}
                        <TrashIcon className="w-4 h-4"/>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default InventoryListPage;