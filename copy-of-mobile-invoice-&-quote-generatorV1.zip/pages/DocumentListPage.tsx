
import React from 'react';
import { useDocuments } from '../contexts/DocumentContext';
import DocumentCard from '../components/DocumentCard';
import FloatingActionButton from '../components/FloatingActionButton';

const DocumentListPage: React.FC = () => {
  const { documents } = useDocuments();

  const sortedDocuments = [...documents].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <div className="animate-fadeIn">
      <h1 className="text-3xl font-bold text-onSurface mb-8">My Documents</h1>
      {sortedDocuments.length === 0 ? (
        <div className="text-center py-10">
          <img src="https://picsum.photos/seed/empty/400/300" alt="No documents" className="mx-auto mb-4 rounded-lg shadow-md w-64 h-48 object-cover" />
          <p className="text-xl text-gray-600">No documents yet.</p>
          <p className="text-gray-500">Click the '+' button to create your first invoice or quotation.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sortedDocuments.map(doc => (
            <DocumentCard key={doc.id} doc={doc} />
          ))}
        </div>
      )}
      <FloatingActionButton to="/new-invoice" title="Create New Document" /> {/* Defaulting to new-invoice, can be /new for choice */}
    </div>
  );
};

export default DocumentListPage;

// Basic fade-in animation
const style = document.createElement('style');
style.innerHTML = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .animate-fadeIn { animation: fadeIn 0.5s ease-out forwards; }
`;
document.head.appendChild(style);