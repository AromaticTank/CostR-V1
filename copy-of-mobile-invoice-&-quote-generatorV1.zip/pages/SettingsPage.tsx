
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDocuments } from '../contexts/DocumentContext';
import { AppSettings, CompanyInfo, PDFTemplate, UserSlot } from '../types';
import { CURRENCIES, PDF_TEMPLATE_OPTIONS, DEFAULT_SETTINGS, MAX_USER_SLOTS } from '../constants';
import { ArrowLeftIcon, ThemeIcon, BankDetailsIcon, TemplatesIcon, UsersSettingsIcon, TaxIcon as TaxSettingsIcon, PrivacyIcon, ShareAppIcon, RateAppIcon, AboutIcon, MyBusinessIcon, PreferencesIcon, PlusIcon, TrashIcon, PencilIcon } from '../components/icons';

// Simple Modal Component (can be moved to components folder)
const Modal: React.FC<{ isOpen: boolean; onClose: () => void; title: string; children: React.ReactNode; size?: 'md' | 'lg' | 'xl' }> = ({ isOpen, onClose, title, children, size = 'md' }) => {
  if (!isOpen) return null;
  let maxWidthClass = 'max-w-md';
  if (size === 'lg') maxWidthClass = 'max-w-lg';
  if (size === 'xl') maxWidthClass = 'max-w-xl';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4 animate-fadeIn">
      <div className={`bg-surface p-6 rounded-lg shadow-xl w-full ${maxWidthClass} max-h-[90vh] flex flex-col`}>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-onSurface">{title}</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
        </div>
        <div className="overflow-y-auto flex-grow pr-2 scrollbar-thin">
            {children}
        </div>
        <button onClick={onClose} className="mt-6 w-full py-2 px-4 bg-primary text-onPrimary rounded-md hover:bg-primary-dark transition-colors">
          Close
        </button>
      </div>
    </div>
  );
};

const UserSlotFormModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  onSave: (name: string, role: string) => void;
  existingSlot?: UserSlot | null;
}> = ({ isOpen, onClose, onSave, existingSlot }) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (existingSlot) {
      setName(existingSlot.name);
      setRole(existingSlot.role);
    } else {
      setName('');
      setRole('');
    }
    setError('');
  }, [existingSlot, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('User name cannot be empty.');
      return;
    }
    if (!role.trim()) {
        setError('Role cannot be empty.');
        return;
    }
    onSave(name, role);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={existingSlot ? 'Edit User Slot' : 'Add User Slot'}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="userName" className="block text-sm font-medium text-gray-700">User Name</label>
          <input
            type="text"
            id="userName"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2"
            placeholder="e.g., John Doe, Front Desk"
          />
        </div>
        <div>
          <label htmlFor="userRole" className="block text-sm font-medium text-gray-700">Role</label>
          <input
            type="text"
            id="userRole"
            value={role}
            onChange={(e) => setRole(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2"
            placeholder="e.g., Sales, Technician, Manager"
          />
        </div>
        {error && <p className="text-sm text-danger">{error}</p>}
        <div className="flex justify-end space-x-3 pt-2">
          <button type="button" onClick={onClose} className="px-4 py-2 text-sm border border-gray-300 rounded-md hover:bg-gray-100">Cancel</button>
          <button type="submit" className="px-4 py-2 text-sm bg-primary text-onPrimary rounded-md hover:bg-primary-dark">{existingSlot ? 'Save Changes' : 'Add User'}</button>
        </div>
      </form>
    </Modal>
  );
};

// fix: Define an interface for setting section items
interface SettingSectionConfig {
  title: string;
  icon: React.ReactNode; // Typically JSX.Element for icons as components
  description: string;
  id: string;
  action?: () => void;
  disabled?: boolean; // Add optional disabled property
}


const SettingsPage: React.FC = () => {
  const { settings, updateSettings, addUserSlot, updateUserSlot, deleteUserSlot } = useDocuments();
  const navigate = useNavigate();
  
  const [currentSettings, setCurrentSettings] = useState<AppSettings>(settings);
  const [isSaved, setIsSaved] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [editingUserSlot, setEditingUserSlot] = useState<UserSlot | null>(null);
  const [isUserSlotModalOpen, setIsUserSlotModalOpen] = useState(false);


  useEffect(() => {
     setCurrentSettings({
        ...DEFAULT_SETTINGS, 
        ...settings, 
        company: settings.company || DEFAULT_SETTINGS.company,
        userSlots: settings.userSlots || [DEFAULT_SETTINGS.userSlots[0]], // Ensure userSlots is initialized
        maxUserSlots: settings.maxUserSlots || MAX_USER_SLOTS,
    });
  }, [settings]);

  const handleCompanyChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setCurrentSettings(prev => ({
      ...prev,
      company: { ...prev.company, [name]: value } as CompanyInfo,
    }));
    setIsSaved(false);
  };

  const handleDefaultChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let processedValue: string | number | undefined | PDFTemplate = value;
    if (name === 'defaultTaxRate' || name === 'secondaryTaxRate') {
      processedValue = value === '' ? undefined : parseFloat(value) || 0;
    } else if (name === 'selectedPdfTemplate') {
      processedValue = value as PDFTemplate;
    }

    setCurrentSettings(prev => ({
      ...prev,
      [name]: processedValue,
    }));
    setIsSaved(false);
  };

  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCurrentSettings(prev => ({ ...prev, [name]: value }));
    setIsSaved(false);
    if (!value.match(/^#[0-9a-fA-F]{6}$/)) {
        setErrors(prev => ({...prev, [name]: "Must be a valid hex color (e.g. #RRGGBB)"}));
    } else {
        setErrors(prev => { const newErrors = {...prev}; delete newErrors[name]; return newErrors; });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (Object.keys(errors).length > 0) {
        alert("Please fix the errors in the form.");
        return;
    }
    // We only pass the parts of settings that can be updated via this form
    // userSlots are managed separately.
    const { userSlots, maxUserSlots, ...otherSettings } = currentSettings;
    updateSettings(otherSettings);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };
  
  const openModal = (modalName: string) => setActiveModal(modalName);
  const closeModal = () => setActiveModal(null);

  const handleAddUserSlot = () => {
    setEditingUserSlot(null);
    setIsUserSlotModalOpen(true);
  };

  const handleEditUserSlot = (slot: UserSlot) => {
    setEditingUserSlot(slot);
    setIsUserSlotModalOpen(true);
  };
  
  const handleSaveUserSlot = (name: string, role: string) => {
    if (editingUserSlot) {
      updateUserSlot(editingUserSlot.id, name, role);
    } else {
      addUserSlot(name, role);
    }
  };
  
  const handleDeleteUserSlot = (slotId: string) => {
    if (window.confirm("Are you sure you want to delete this user slot?")) {
      deleteUserSlot(slotId);
    }
  };

  // fix: Apply the SettingSectionConfig interface to the array
  const settingSections: SettingSectionConfig[] = [
    { title: "My Business", icon: <MyBusinessIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Manage company profile, logo, and bank details.", id: "myBusiness" },
    { title: "Theme Customization", icon: <ThemeIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Personalize app appearance with your brand colors.", id: "theme"},
    { title: "Document Defaults", icon: <PreferencesIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Set default currency and tax rates.", id: "documentDefaults"},
    { title: "Tax Settings", icon: <TaxSettingsIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Manage VAT rates and other tax configurations.", id: "taxSettings" },
    { title: "PDF Templates", icon: <TemplatesIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Choose between different invoice/quote layouts.", id: "pdfTemplates" },
    { title: "User Management", icon: <UsersSettingsIcon className="w-5 h-5 mr-3 text-primary"/>, description: `Manage user slots for your organization (up to ${currentSettings.maxUserSlots} users).`, id: "userManagement"},
    { title: "Privacy & Security", icon: <PrivacyIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Understand how your data is managed and your rights.", id: "privacy", action: () => openModal('privacy') },
    { title: "Share App", icon: <ShareAppIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Tell your friends about this app.", id: "shareApp", action: () => openModal('share') },
    { title: "Rate App", icon: <RateAppIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Enjoying the app? Leave a review!", id: "rateApp", action: () => openModal('rate') },
    { title: "About", icon: <AboutIcon className="w-5 h-5 mr-3 text-primary"/>, description: "Information about the application.", id: "about", action: () => openModal('about') },
  ];


  return (
    <div className="max-w-3xl mx-auto bg-surface p-4 sm:p-6 rounded-xl shadow-xl">
       <button onClick={() => navigate(-1)} className="flex items-center text-primary hover:text-primary-dark mb-6 group print-hide">
        <ArrowLeftIcon className="w-5 h-5 mr-2 transition-transform group-hover:-translate-x-1" />
        Back
      </button>
      <h1 className="text-3xl font-bold text-onSurface mb-8">Settings</h1>
      
      {isSaved && (
        <div className="mb-6 p-3 bg-green-100 text-green-700 rounded-lg shadow text-sm animate-fadeIn">
          Settings saved successfully! (User slot changes are saved instantly)
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-10">
        
        <section id="myBusiness" className="p-5 bg-gray-50 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-700 mb-1 flex items-center"><MyBusinessIcon className="w-5 h-5 mr-2 text-primary"/>Your Company Information</h2>
          <p className="text-sm text-gray-500 mb-4">This information will be used as default on new documents.</p>
          <div className="space-y-4">
            <div>
              <label htmlFor="companyName" className="block text-sm font-medium text-gray-700">Company Name</label>
              <input type="text" id="companyName" name="name" value={currentSettings.company.name || ''} onChange={handleCompanyChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="Your Company LLC"/>
            </div>
            <div>
              <label htmlFor="companyAddress" className="block text-sm font-medium text-gray-700">Address</label>
              <textarea id="companyAddress" name="address" value={currentSettings.company.address || ''} onChange={handleCompanyChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="123 Business Rd, Suite 456, City, Country"/>
            </div>
            <div>
              <label htmlFor="companyEmail" className="block text-sm font-medium text-gray-700">Email</label>
              <input type="email" id="companyEmail" name="email" value={currentSettings.company.email || ''} onChange={handleCompanyChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="contact@yourcompany.com"/>
            </div>
            <div>
              <label htmlFor="companyPhone" className="block text-sm font-medium text-gray-700">Phone (Optional)</label>
              <input type="tel" id="companyPhone" name="phone" value={currentSettings.company.phone || ''} onChange={handleCompanyChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="+1-555-123-4567"/>
            </div>
            <div>
              <label htmlFor="logoUrl" className="block text-sm font-medium text-gray-700">Logo URL (Optional)</label>
              <input type="url" id="logoUrl" name="logoUrl" value={currentSettings.company.logoUrl || ''} onChange={handleCompanyChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="https://example.com/logo.png"/>
               {currentSettings.company.logoUrl && <img src={currentSettings.company.logoUrl} alt="logo preview" className="mt-2 h-16 w-auto rounded border p-1"/>}
            </div>
             <div>
              <label htmlFor="taxId" className="block text-sm font-medium text-gray-700">Tax ID / VAT Number (Optional)</label>
              <input type="text" id="taxId" name="taxId" value={currentSettings.company.taxId || ''} onChange={handleCompanyChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="Your Tax ID"/>
            </div>
            <div>
              <label htmlFor="bankDetails" className="block text-sm font-medium text-gray-700 flex items-center"><BankDetailsIcon className="w-4 h-4 mr-2 text-gray-600"/>Bank Details (Optional)</label>
              <textarea id="bankDetails" name="bankDetails" value={currentSettings.company.bankDetails || ''} onChange={handleCompanyChange} rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="Bank Name, Account Number, SWIFT/BIC"/>
            </div>
          </div>
        </section>

        <section id="theme" className="p-5 bg-gray-50 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-700 mb-1 flex items-center"><ThemeIcon className="w-5 h-5 mr-2 text-primary"/>Theme Customization</h2>
           <p className="text-sm text-gray-500 mb-4">Personalize the app's look and feel.</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="primaryColor" className="block text-sm font-medium text-gray-700">Primary Color</label>
              <div className="mt-1 flex rounded-md shadow-sm">
                  <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50">
                      <div style={{ backgroundColor: currentSettings.primaryColor }} className="w-5 h-5 rounded-sm border border-gray-400"></div>
                  </span>
                  <input type="text" id="primaryColor" name="primaryColor" value={currentSettings.primaryColor} onChange={handleColorChange} className="block w-full flex-1 rounded-none rounded-r-md border-gray-300 focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="#3B82F6"/>
              </div>
              {errors.primaryColor && <p className="text-danger text-xs mt-1">{errors.primaryColor}</p>}
            </div>
            <div>
              <label htmlFor="secondaryColor" className="block text-sm font-medium text-gray-700">Secondary Color</label>
               <div className="mt-1 flex rounded-md shadow-sm">
                  <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50">
                      <div style={{ backgroundColor: currentSettings.secondaryColor }} className="w-5 h-5 rounded-sm border border-gray-400"></div>
                  </span>
                  <input type="text" id="secondaryColor" name="secondaryColor" value={currentSettings.secondaryColor} onChange={handleColorChange} className="block w-full flex-1 rounded-none rounded-r-md border-gray-300 focus:border-primary focus:ring-primary sm:text-sm p-2" placeholder="#10B981"/>
              </div>
              {errors.secondaryColor && <p className="text-danger text-xs mt-1">{errors.secondaryColor}</p>}
            </div>
          </div>
        </section>

        <section id="documentDefaults" className="p-5 bg-gray-50 rounded-lg shadow-sm">
          <h2 className="text-xl font-semibold text-gray-700 mb-1 flex items-center"><PreferencesIcon className="w-5 h-5 mr-2 text-primary"/>Default Document Settings</h2>
           <p className="text-sm text-gray-500 mb-4">Applied to new invoices and quotes.</p>
          <div className="space-y-4">
            <div>
              <label htmlFor="defaultCurrency" className="block text-sm font-medium text-gray-700">Default Currency</label>
              <select id="defaultCurrency" name="defaultCurrency" value={currentSettings.defaultCurrency} onChange={handleDefaultChange} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2 bg-white">
                {CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>
        </section>

        <section id="taxSettings" className="p-5 bg-gray-50 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold text-gray-700 mb-1 flex items-center"><TaxSettingsIcon className="w-5 h-5 mr-2 text-primary"/>Tax Settings</h2>
            <p className="text-sm text-gray-500 mb-4">Configure default tax rates for your documents.</p>
            <div className="space-y-4">
                <div>
                    <label htmlFor="defaultTaxRate" className="block text-sm font-medium text-gray-700">Default Tax Rate (%)</label>
                    <input type="number" id="defaultTaxRate" name="defaultTaxRate" value={currentSettings.defaultTaxRate} onChange={handleDefaultChange} step="0.01" min="0" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                </div>
                <div>
                    <label htmlFor="secondaryTaxRate" className="block text-sm font-medium text-gray-700">Secondary Tax Rate (%) (Optional)</label>
                    <input type="number" id="secondaryTaxRate" name="secondaryTaxRate" value={currentSettings.secondaryTaxRate === undefined ? '' : currentSettings.secondaryTaxRate} onChange={handleDefaultChange} step="0.01" min="0" placeholder="e.g., 5 for an additional 5%" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm p-2" />
                    <p className="text-xs text-gray-500 mt-1">Used for complex tax scenarios if applicable. Leave blank if not needed.</p>
                </div>
            </div>
        </section>

        <section id="pdfTemplates" className="p-5 bg-gray-50 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold text-gray-700 mb-1 flex items-center"><TemplatesIcon className="w-5 h-5 mr-2 text-primary"/>PDF Templates</h2>
            <p className="text-sm text-gray-500 mb-4">Choose the layout for your generated PDF documents.</p>
            <fieldset className="space-y-2">
                <legend className="sr-only">PDF Template Selection</legend>
                {PDF_TEMPLATE_OPTIONS.map(opt => (
                    <div key={opt.value} className="flex items-center">
                        <input 
                            id={`template-${opt.value}`} 
                            name="selectedPdfTemplate" 
                            type="radio" 
                            value={opt.value}
                            checked={currentSettings.selectedPdfTemplate === opt.value}
                            onChange={handleDefaultChange}
                            className="focus:ring-primary h-4 w-4 text-primary border-gray-300"
                        />
                        <label htmlFor={`template-${opt.value}`} className="ml-3 block text-sm font-medium text-gray-700">
                            {opt.label}
                        </label>
                    </div>
                ))}
            </fieldset>
             <p className="text-xs text-orange-500 mt-3">(Visual differences between templates are currently minimal and will be enhanced later.)</p>
        </section>
        
        <div className="pt-6 print-hide">
          <button type="submit" className="w-full px-6 py-3 bg-primary hover:bg-primary-dark text-onPrimary rounded-lg shadow-md hover:shadow-lg transition-all text-sm font-medium">
            Save All General Settings
          </button>
        </div>
      </form>

      {/* User Management Section - Separate from main form submit */}
      <section id="userManagement" className="p-5 mt-10 bg-gray-50 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-4">
            <div>
                <h2 className="text-xl font-semibold text-gray-700 flex items-center"><UsersSettingsIcon className="w-5 h-5 mr-2 text-primary"/>User Management</h2>
                <p className="text-sm text-gray-500">Manage user slots for your organization ({currentSettings.userSlots.length} / {currentSettings.maxUserSlots} used).</p>
            </div>
            {currentSettings.userSlots.length < currentSettings.maxUserSlots && (
                <button onClick={handleAddUserSlot} className="bg-secondary hover:bg-green-600 text-onSecondary text-sm font-medium py-2 px-3 rounded-lg shadow hover:shadow-md transition-all flex items-center">
                    <PlusIcon className="w-4 h-4 mr-1.5" /> Add User
                </button>
            )}
        </div>
        {currentSettings.userSlots.length === 0 ? (
            <p className="text-sm text-gray-500">No user slots defined. The primary admin is counted as the first slot upon setup completion.</p>
        ) : (
            <ul className="space-y-3">
            {currentSettings.userSlots.map(slot => (
                <li key={slot.id} className="p-3 bg-white rounded-md shadow-sm border border-gray-200 flex justify-between items-center">
                <div>
                    <p className="font-medium text-gray-800">{slot.name} {slot.isPrimaryAdmin ? <span className="text-xs bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full ml-1">Admin</span> : ''}</p>
                    <p className="text-sm text-gray-500">{slot.role}</p>
                </div>
                <div className="flex space-x-2">
                    <button onClick={() => handleEditUserSlot(slot)} className="p-1.5 text-gray-500 hover:text-secondary rounded-full hover:bg-secondary/10" title="Edit User">
                    <PencilIcon className="w-4 h-4" />
                    </button>
                    {!slot.isPrimaryAdmin && (
                    <button onClick={() => handleDeleteUserSlot(slot.id)} className="p-1.5 text-gray-500 hover:text-danger rounded-full hover:bg-danger/10" title="Delete User">
                        <TrashIcon className="w-4 h-4" />
                    </button>
                    )}
                </div>
                </li>
            ))}
            </ul>
        )}
        <p className="text-xs text-gray-400 mt-3">Note: User slots are for organizational purposes within this local application. They do not provide separate logins or data segregation across different devices.</p>
      </section>

      {/* Other setting sections with actions */}
      <div className="mt-10 space-y-6">
        {settingSections.filter(s => !["myBusiness", "theme", "documentDefaults", "taxSettings", "pdfTemplates", "userManagement"].includes(s.id)).map(section => (
          <div key={section.id} id={section.id} className={`p-5 bg-gray-50 rounded-lg shadow-sm ${section.disabled ? 'opacity-60' : 'hover:bg-gray-100 transition-colors cursor-pointer'}`} onClick={!section.disabled && section.action ? section.action : undefined}>
            <h2 className="text-xl font-semibold text-gray-700 mb-1 flex items-center">{section.icon}{section.title}</h2>
            <p className="text-sm text-gray-500 mb-2">{section.description}</p>
            {section.disabled && <p className="text-xs text-orange-500">(Feature under consideration)</p>}
          </div>
        ))}
      </div>


      <Modal isOpen={activeModal === 'about'} onClose={closeModal} title="About Business Hub">
        <p className="text-sm text-gray-600">Business Hub v1.0.1</p>
        <p className="text-sm text-gray-600 mt-2">A simple invoice, quotation, customer, inventory, and expense management app.</p>
        <p className="text-sm text-gray-600 mt-2">&copy; {new Date().getFullYear()}. All data is stored locally in your browser.</p>
      </Modal>
      <Modal isOpen={activeModal === 'share'} onClose={closeModal} title="Share Business Hub">
        <p className="text-sm text-gray-600">Tell your friends about Business Hub!</p>
        <button 
            onClick={() => {
                if (navigator.share) {
                    navigator.share({
                        title: 'Business Hub App',
                        text: 'Check out Business Hub for managing invoices, quotes, and more!',
                        url: window.location.href
                    }).catch(console.error);
                } else {
                    alert("Sharing is not supported on this browser/device, or you are not on HTTPS. You can copy the URL: " + window.location.href);
                }
            }}
            className="mt-4 w-full py-2 px-4 bg-secondary text-onSecondary rounded-md hover:bg-green-600 transition-colors"
        >
            Share Now
        </button>
      </Modal>
      <Modal isOpen={activeModal === 'rate'} onClose={closeModal} title="Rate Business Hub">
        <p className="text-sm text-gray-600">If you enjoy using Business Hub, please consider leaving a review or feedback!</p>
        <p className="text-sm text-gray-500 mt-2">(This is a demo app, so there's no actual rating system. Imagine a link to an app store or feedback form here.)</p>
      </Modal>
       <Modal isOpen={activeModal === 'privacy'} onClose={closeModal} title="Privacy & Security Information (POPIA)" size="xl">
        <div className="text-sm text-gray-700 space-y-3">
            <p className="font-semibold">Introduction</p>
            <p>This application ("App") is designed to help you manage your business information, including company details, customer data, invoices, quotations, inventory, and financial transactions. We are committed to protecting your privacy and ensuring that your personal information, and that of your clients, is handled in accordance with the Protection of Personal Information Act (POPIA) of South Africa.</p>
            <p>Please note: You, as the user of this App, are considered the "Responsible Party" (similar to a Data Controller) for the personal information you collect and process using this App, especially concerning your clients' data. This policy primarily explains how the App itself handles data.</p>

            <p className="font-semibold mt-2">Information We Process</p>
            <p>The App processes information that you voluntarily provide, which may include:</p>
            <ul className="list-disc list-inside ml-4">
                <li><strong>Your Company Information:</strong> Name, address, email, phone, logo URL, bank details, tax ID.</li>
                <li><strong>Client Information:</strong> Name, email, address, phone numbers, and any notes you add.</li>
                <li><strong>Document Details:</strong> Invoice and quotation specifics, line items, financial totals.</li>
                <li><strong>Inventory Information:</strong> Item names, SKUs, descriptions, quantities, prices.</li>
                <li><strong>Payment Transactions:</strong> Dates, amounts, descriptions, categories related to income and expenses.</li>
                <li><strong>User Slot Information:</strong> Names and roles you assign to user slots for your organization.</li>
            </ul>
            
            <p className="font-semibold mt-2">How Information is Collected and Used (Purpose)</p>
            <p>All information is collected directly through your input into the App. The purpose of collecting and processing this information is solely to enable the core functionalities of the App, allowing you to generate documents, manage client relationships, track inventory, and record financial transactions for your business operations.</p>

            <p className="font-semibold mt-2">Data Storage, Security, and Location</p>
            <p><strong>All data you enter into this App is stored locally within your web browser's storage on your specific device. The App does not transmit your data to any external server or third party by default.</strong></p>
            <ul className="list-disc list-inside ml-4">
                <li>Security of your data depends on the security of your device and browser. It is your responsibility to ensure your device and browser are secure (e.g., using passwords, up-to-date software).</li>
                <li>If you clear your browser's cache or site data for this App, all stored information will be permanently deleted.</li>
                <li>Data is not automatically synced or accessible across different browsers or devices. Each instance of the App in a different browser or on a different device maintains its own separate local data store.</li>
            </ul>

            <p className="font-semibold mt-2">Data Sharing and Disclosure</p>
            <p>The App itself does not share your data with any third parties. Any sharing of data (e.g., sending an invoice PDF to a client) is an action you explicitly initiate through the App's functionalities (like printing or saving a PDF) or by other means outside the App.</p>

            <p className="font-semibold mt-2">Your Rights under POPIA (as a User and Responsible Party)</p>
            <p>As a user of this App, and as a Responsible Party for your clients' data:</p>
            <ul className="list-disc list-inside ml-4">
                <li><strong>Right to Access:</strong> You can access all information stored by the App by simply using the App. Your clients have the right to request access to their personal information that you hold.</li>
                <li><strong>Right to Correction:</strong> You can correct your company information and client information directly within the App. Your clients can request you to correct their information.</li>
                <li><strong>Right to Deletion:</strong> You can delete specific records (documents, customers, etc.) within the App. To delete all data, you can clear your browser's site data for this App. Your clients can request the deletion of their data, subject to any legal obligations you may have to retain it.</li>
                <li><strong>Right to Object:</strong> You and your clients can object to the processing of personal information under certain conditions. Since this App processes data for your direct use, objecting would typically mean ceasing to use the App for that data.</li>
                <li><strong>Right to Complain:</strong> If you or your clients believe that your/their personal information is not being processed in compliance with POPIA, you/they have the right to lodge a complaint with the Information Regulator of South Africa.</li>
            </ul>

            <p className="font-semibold mt-2">Data Retention</p>
            <p>The App will retain your data in your browser's local storage as long as you use the App and do not clear the browser's site data. It is your responsibility to manage data retention according to your business needs and any legal requirements.</p>
            
            <p className="font-semibold mt-2">Use of Cookies and Other Technologies</p>
            <p>This App uses `localStorage` in your browser to store your data. It does not use tracking cookies for its core functionality. Standard browser operations might involve other temporary storage mechanisms not directly controlled by the App's code.</p>

            <p className="font-semibold mt-2">Cross-Border Data Transfer</p>
            <p>As all data is stored locally in your browser, there is no cross-border transfer of data initiated by the App itself.</p>

            <p className="font-semibold mt-2">Updates to this Information</p>
            <p>This privacy information may be updated if the App's functionality changes significantly. Any updates will be accessible within this section of the App.</p>
            
            <p className="font-semibold mt-2">Disclaimer</p>
            <p>This information is provided to help you understand how the App handles data in the context of POPIA. It is not exhaustive legal advice. You should consult with a legal professional to ensure your business practices fully comply with POPIA and other relevant regulations.</p>
        </div>
      </Modal>

      <UserSlotFormModal
        isOpen={isUserSlotModalOpen}
        onClose={() => setIsUserSlotModalOpen(false)}
        onSave={handleSaveUserSlot}
        existingSlot={editingUserSlot}
      />

    </div>
  );
};

export default SettingsPage;
// Helper for scrollbar styling
const styleElement = document.createElement('style');
styleElement.innerHTML = `
  .scrollbar-thin::-webkit-scrollbar {
    width: 8px;
    height: 8px;
  }
  .scrollbar-thin::-webkit-scrollbar-track {
    background: var(--color-background);
  }
  .scrollbar-thin::-webkit-scrollbar-thumb {
    background-color: var(--color-primary-light);
    border-radius: 10px;
    border: 2px solid var(--color-background);
  }
  .scrollbar-thin::-webkit-scrollbar-thumb:hover {
    background-color: var(--color-primary-DEFAULT);
  }
`;
document.head.appendChild(styleElement);
