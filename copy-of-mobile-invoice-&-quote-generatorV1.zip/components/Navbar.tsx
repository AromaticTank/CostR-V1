// This file is deprecated and replaced by TopNavbar.tsx
// Keeping the content here temporarily for reference if needed for migration.
// The new TopNavbar.tsx will have different functionality (menu icon, profile icon).

/*
import React from 'react';
import { Link } from 'react-router-dom';
import { APP_NAME } from '../constants';
import { CogIcon } from './icons'; // CogIcon will move to profile or settings access

const Navbar: React.FC = () => {
  return (
    <nav className="bg-primary shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold text-onPrimary">
              {APP_NAME}
            </Link>
          </div>
          <div className="flex items-center">
            <Link
              to="/settings"
              className="text-onPrimary hover:bg-primary-light p-2 rounded-full transition-colors"
              aria-label="Settings"
            >
              <CogIcon className="w-6 h-6" />
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
*/
