
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  DashboardIcon, CustomersIcon, InventoryIcon, QuotesIcon, InvoicesIcon,
  PaymentsInIcon, PaymentsOutIcon, ReportsIcon, MyBusinessIcon, SettingsMenuIcon,
  LogoutMenuIcon
} from './icons'; // Assuming these are UserCircle2, Archive, etc. from lucide-react
import { APP_NAME } from '../constants';
import { useDocuments } from '../contexts/DocumentContext';


interface SideMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

interface NavItemProps {
  to: string;
  icon: React.ReactNode;
  label: string;
  onClose: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ to, icon, label, onClose }) => {
  const location = useLocation();
  const isActive = location.pathname === to || (label === "Dashboard" && location.pathname.startsWith("/dashboard"));


  return (
    <Link
      to={to}
      onClick={onClose}
      className={`flex items-center px-4 py-3 text-base rounded-lg transition-colors duration-150 ease-in-out
                  ${isActive ? 'bg-primary-light/20 text-primary-dark font-semibold' : 'text-onBackground hover:bg-gray-100'}`}
    >
      <span className="mr-4">{icon}</span>
      {label}
    </Link>
  );
};

const SideMenu: React.FC<SideMenuProps> = ({ isOpen, onClose }) => {
  const { settings } = useDocuments();

  const menuItems = [
    { to: '/dashboard', icon: <DashboardIcon />, label: 'Dashboard' },
    { to: '/customers', icon: <CustomersIcon />, label: 'Customers' },
    { to: '/inventory', icon: <InventoryIcon />, label: 'Inventory' },
    { to: '/quotes', icon: <QuotesIcon />, label: 'Quotes' },
    { to: '/invoices', icon: <InvoicesIcon />, label: 'Invoices' },
    { to: '/payments-in', icon: <PaymentsInIcon />, label: 'Payments In' },
    { to: '/payments-out', icon: <PaymentsOutIcon />, label: 'Payments Out' },
    { to: '/reports', icon: <ReportsIcon />, label: 'Reports' },
    { to: '/my-business', icon: <MyBusinessIcon />, label: 'My Business' },
    { to: '/settings', icon: <SettingsMenuIcon />, label: 'Settings' },
  ];

  return (
    <>
      {/* Overlay for mobile */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-30 transition-opacity duration-300 md:hidden ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      ></div>

      {/* Side Menu Panel */}
      <aside
        className={`fixed top-0 left-0 w-72 h-full bg-surface shadow-xl z-40 transform transition-transform duration-300 ease-in-out print-hide ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
        aria-label="Main navigation"
      >
        <div className="flex flex-col h-full">
          <div className="px-6 py-5 border-b border-gray-200">
            <Link to="/dashboard" onClick={onClose} className="flex items-center space-x-2">
              {/* Optional: Add a small logo here if available in settings.company.logoUrl */}
              {settings.company.logoUrl && <img src={settings.company.logoUrl} alt="logo" className="h-8 w-8 rounded-full object-cover" />}
              <span className="text-xl font-bold text-primary-dark">{APP_NAME}</span>
            </Link>
          </div>

          <nav className="flex-grow p-4 space-y-1 overflow-y-auto">
            {menuItems.map(item => (
              <NavItem key={item.to} {...item} onClose={onClose} />
            ))}
          </nav>

          <div className="p-4 border-t border-gray-200">
            {/* Placeholder for future logout or other actions */}
            {/* <button 
                onClick={() => { console.log('Logout clicked'); onClose(); }}
                className="flex items-center w-full px-4 py-3 text-base text-gray-600 hover:bg-gray-100 rounded-lg"
            >
                <LogoutMenuIcon className="mr-3" />
                Logout
            </button> */}
          </div>
        </div>
      </aside>
    </>
  );
};

export default SideMenu;
